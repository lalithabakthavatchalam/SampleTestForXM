package Hooks;

import org.openqa.selenium.WebDriver;

import DriverFactory.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {
	
	public static WebDriver driver;
	
	@Before
	public void initializeTest(Scenario scenario) throws Exception {
		
		System.out.println("Execution started for scenario - " + scenario.getName());
		driver = DriverFactory.startDriver("chrome");
		System.out.println("Browser got launched and maximised");
		
	}
	
	
	@After
	public void tearDown(Scenario scenario) {
		
		System.out.println("Finishing the scenario and Browser is closed");
		System.out.println("Execution finished for scenario - " + scenario.getName());
		driver.close();
		driver.quit();

	}

}
