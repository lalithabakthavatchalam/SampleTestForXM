package DriverFactory;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class DriverFactory {
	
	public static WebDriver driver;
	
	
	
	public static WebDriver startDriver(String browserName) throws Exception {
		
		String projectLocation = System.getProperty("user.dir");

		
		switch(browserName.toLowerCase()) {
		case "chrome": 
			System.setProperty("webdriver.chrome.driver", "//usr//local//bin//chromedriver");
			driver = new ChromeDriver();
			break;
		
		case "firefox":
			System.setProperty("webdriver.gecko.driver", "//Drivers//geckodriver.exe");
			driver = new FirefoxDriver();
			break;
		
		case "ie":
			System.setProperty("webdriver.ir.driver", "//Drivers//IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			break;
			
		default:
			throw new Exception("Invalid browser name: " + browserName);

			
		}
		
		driver.manage().window().maximize();
		
		return driver;
				
		
	}
	
	
	public static void getSizeOfBrowserWindow(String dimensions) {
		
		if (dimensions.equals("1024, 768")) {
			
			driver.manage().window().setSize(new Dimension(1024, 768));

		}
		
		else if (dimensions.equals("800, 600")) {
			
			driver.manage().window().setSize(new Dimension(800, 600));

		}
		
				
	}
	

}
