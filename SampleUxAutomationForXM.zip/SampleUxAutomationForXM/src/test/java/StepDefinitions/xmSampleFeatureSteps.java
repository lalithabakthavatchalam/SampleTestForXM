package StepDefinitions;

import Pages.XmHomePage;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class xmSampleFeatureSteps extends XmHomePage{
	
	@Given("I am navigating to {string} of XM website")
	public void i_am_navigating_to_website(String env) throws InterruptedException {
		navigateToUrl(env);
		System.out.println("User is in the home screen");
	}

	@When("I am on the Home screen of XM website")
	public void i_am_on_the_home_screen_of_xm_website() throws InterruptedException {
		verifyUserOnHomeScreen();
		System.out.println("User is in the home screen");	    
	}
	
	@When("I am on Research and Education section")
	public void i_am_on_the_research_section() throws InterruptedException {
		verifyUserOnHomeScreen();
		clickLink("Research and Education");
		System.out.println("User is in the Research and Education section");	    

	}
	
	@Then("the following fields are displayed in the Home screen of XM website")
	public void the_following_fields_are_displayed_in_the_home_screen_of_xm_website(DataTable dataTable) {
		verifyFollowingFieldsAreDisplayedInHomeScreen(dataTable);
		System.out.println("The Expected fields are displayed as expected in the Home screen.");

	}

	@When("I click the {string} Link in the Home screen")
	public void i_click_the_link_in_the_home_screen(String link) throws InterruptedException {
		clickLink(link);
	}

	@Then("the following fields are displayed in the Research section")
	public void the_following_fields_are_displayed_in_the_section(DataTable dataTable) {
		verifyFollowingFieldsAreDisplayedInResearchSection(dataTable);
	}
	
	@Then("the following fields are displayed in the Economic Calender section")
	public void the_following_fields_are_displayed_in_the_economic_section(DataTable dataTable) {
		verifyFollowingFieldsAreDisplayedInEconomicCalendarSection(dataTable);
	}

	@When("I click the {string} Link in the Research and Education")
	public void i_click_the_link_in_the_research_and_education(String link) throws InterruptedException {
		clickLink(link);
	}

	@When("I click the slider and move it to {string}")
	public void i_click_the_slider_times_and_move_it_to(String date) {
		clickSliderButton(date);
	}

	@Then("I can view the date as expected {string}")
	public void i_can_view_the_date_as_expected(String date) {
		viewDateAsExpected(date);
	}

	@Given("I scroll through the bottom of the screen")
	public void i_scroll_through_the_bottom_of_the_screen() {
		scrollToTheBottomOfScreen();
	}

	@Then("it takes me to the Notification on Non-Independent Investment Research and Risk Warning Screen")
	public void it_takes_me_to_the_notification_screen() {
		verifyUserInNotificationScreen();
	}

	@When("I click the Risk Closure Link in the Risk Warning block")
	public void i_click_the_link_in_the_risk_warning_block() {
		clickLinkInRiskWarningBlock();
	}

	@Then("it takes me to the new tab to open the Risk closure document")
	public void it_takes_me_to_the_new_tab_to_open_the_risk_closure_document() {
		verifyDocumentOpensInNewTab();
	}

}
