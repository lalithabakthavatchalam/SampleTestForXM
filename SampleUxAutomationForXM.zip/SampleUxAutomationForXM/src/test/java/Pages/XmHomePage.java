package Pages;

import java.util.List;
import java.util.NoSuchElementException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.JavascriptExecutor;


import PageObject.PageObjects;
import io.cucumber.datatable.DataTable;

public class XmHomePage extends PageObjects{
	
    public static String qaXM = "https://www.xm.com/";
    
    
    public void navigateToUrl(String env) throws InterruptedException {
    	if (env.equals("Staging QA")) {
    		DriverFactory.DriverFactory.driver.get(qaXM);
    	}    	
    }
    
    
    public void verifyUserOnHomeScreen() throws InterruptedException {
    	Thread.sleep(2000);
    	WebElement preferenceModal = DriverFactory.DriverFactory.driver.findElement(By.xpath("//*[@id='cookieModal']/div/div"));
    	assert(preferenceModal).isDisplayed();
		System.out.println("The Pop up for the preferences is displayed");
    	WebElement acceptAllButton = DriverFactory.DriverFactory.driver.findElement(By.xpath("//*[@id='cookieModal']/div/div/div[1]/div[3]/div[2]/div[3]/button"));
		assert acceptAllButton.isDisplayed();
        System.out.println("The acceptAllButton is displayed in the Modal");
        acceptAllButton.click();
        System.out.println("The acceptAllButton is clicked");
        System.out.println("The user is on the Home screen of the XM Website");    
    } 

		
    
    public static void verifyFollowingFieldsAreDisplayedInHomeScreen(DataTable dt) {
        ArrayList<String> foundStrings = new ArrayList<>();
        WebElement navigationBarForXM = DriverFactory.DriverFactory.driver.findElement(By.xpath("//div[@id='main-nav']"));    
        WebElement contentBlock = DriverFactory.DriverFactory.driver.findElement(By.xpath("//*[@id=\"hero-content\"]/div[4]/div[1]"));        
        WebElement xmLogo = DriverFactory.DriverFactory.driver.findElement(By.xpath("//*[@id=\"navigation-collapse\"]/div/div[1]/a"));        
    
        try {
        	if (xmLogo.isDisplayed()) {
                foundStrings.add("XM Logo");
                System.out.println("XM Logo is displayed");
            }
            if (contentBlock.isDisplayed()) {
                foundStrings.add("XM Main Content");
                System.out.println("XM Main Content is displayed");
            }
            if (navigationBarForXM.isDisplayed()) {
                foundStrings.add("Navigation Bar");
                System.out.println("Navigation Bar is displayed");
            }
        } catch (NoSuchElementException e) {
            e.printStackTrace();
        }

        List<String> expectedStrings = new ArrayList<>();
        List<List<String>> dtCells = dt.cells(); 

        for (List<String> cell : dtCells) {
            expectedStrings.addAll(cell);
        }

        for (int i = 0; i < expectedStrings.size(); i++) {
            if (i < foundStrings.size() && foundStrings.get(i).contains(expectedStrings.get(i))) {
            
            }
        }

        System.out.println("Expected fields in the XM Home Screen on Page Load: " + expectedStrings);
        System.out.println("Found fields in the XM Home Screen on Page Load: " + foundStrings);
    }
    
    
    public static void clickLink(String linkName) throws InterruptedException {
    	List <WebElement> navbarElements = DriverFactory.DriverFactory.driver.findElements(By.xpath("//ul[@id='main-nav']//li//a"));    
    	List <WebElement> listElements = DriverFactory.DriverFactory.driver.findElements(By.xpath("//div[@class='block']//ul//li//a"));    
   	
    	if(linkName.equals("HOME")) {
    		navbarElements.get(0).click();
    		System.out.println("Home link is clicked");
    		assert(navbarElements.get(0).getText().equals("HOME"));
    	}
    	
    	if(linkName.equals("Research and Education")) {
    		assert(navbarElements.get(38).getText().equals("RESEARCH & EDUCATION"));
    		navbarElements.get(38).click();
    		System.out.println("Research and Education link is clicked");
    	}
    	
    	if(linkName.equals("Economic Calender")) {
    		assert(listElements.get(36).getText().equals("Economic Calendar"));
    		listElements.get(36).click();
    		System.out.println("Economic Calendar ink is clicked");
    		Thread.sleep(5000);
    	}   	
    	
    	if(linkName.equals("Disclaimer")) {		
            WebElement disclaimerLink = DriverFactory.DriverFactory.driver.findElement(By.xpath("//*[@id='research-app']/div[4]/div/p[3]/a"));        
            disclaimerLink.click();
    		System.out.println("Disclaimer ink is clicked");
    	}   
    }
    
    
    public static void verifyFollowingFieldsAreDisplayedInResearchSection(DataTable dt) {
        ArrayList<String> foundStrings = new ArrayList<>();
    	List <WebElement> tabBlocksInResearchAndEducation = DriverFactory.DriverFactory.driver.findElements(By.xpath("//div[@class='block']"));    
        WebElement researchAndEducationHeader = DriverFactory.DriverFactory.driver.findElement(By.xpath("//*[@id='main-nav']/li[4]/div/div/div[1]/span"));        

        try {
        	
        	if (researchAndEducationHeader.isDisplayed()) {
                foundStrings.add("Research and Education Header");
                System.out.println("Research and Education Header and its contents are displayed");
            }       	
        	if (tabBlocksInResearchAndEducation.get(7).isDisplayed()) {
                foundStrings.add("Research Tab with List");
                System.out.println("Research Tab with its contents are displayed");
            }       	
        	if (tabBlocksInResearchAndEducation.get(8).isDisplayed()) {
                foundStrings.add("Learning Center Tab with List");
                System.out.println("Learning Center Tab with its contents are displayed");
            }  
        	if (tabBlocksInResearchAndEducation.get(9).isDisplayed()) {
                foundStrings.add("Tools Tab with List");
                System.out.println("Tools Tab with its contents are displayed");
            }
         
        } catch (NoSuchElementException e) {
            e.printStackTrace();
        }

        List<String> expectedStrings = new ArrayList<>();
        List<List<String>> dtCells = dt.cells(); 

        for (List<String> cell : dtCells) {
            expectedStrings.addAll(cell);
        }

        for (int i = 0; i < expectedStrings.size(); i++) {
            if (i < foundStrings.size() && foundStrings.get(i).contains(expectedStrings.get(i))) {
            
            }
        }
        System.out.println("Expected fields in the Research and Education section is : " + expectedStrings);
        System.out.println("Found fields in the Research and Education section is : " + foundStrings);
    }
    
    
    public static void verifyFollowingFieldsAreDisplayedInEconomicCalendarSection(DataTable dt) {
    	DriverFactory.DriverFactory.driver.switchTo().frame("iFrameResizer0");
    	ArrayList<String> foundStrings = new ArrayList<>();
    	List <WebElement> labelsInTableSection = DriverFactory.DriverFactory.driver.findElements(By.xpath("//tc-economic-calendar-row[1]/div/div"));    
    	List <WebElement> rowsInCalendarTable = DriverFactory.DriverFactory.driver.findElements(By.xpath("//*[@id='economic-calendar-list']/div[3]/div[1]/span"));    
    	WebElement slider = DriverFactory.DriverFactory.driver.findElement(By.xpath("//mat-slider"));        
        WebElement calendarTableHeader = DriverFactory.DriverFactory.driver.findElement(By.xpath("//*[@id='economic-calendar-list-id']/div"));        
      
        try {
        	     	
        	if (slider.isDisplayed()) {
                foundStrings.add("Calendar Slider");
                System.out.println("Calendar Slider is displayed");
            }       	
        	if (calendarTableHeader.isDisplayed()) {
                foundStrings.add("Header for Calendar Table");
                System.out.println("Header for the Calendar table is displayed");
            }  
        	if (labelsInTableSection.get(0).isDisplayed()) {
                foundStrings.add("Calendar Date Label");
                System.out.println("Calendar Date label is displayed");
            }
        	if (labelsInTableSection.get(1).isDisplayed()) {
                foundStrings.add("Calendar Day Label");
                System.out.println("Calendar Day label is displayed");
            }
        	if (rowsInCalendarTable.get(0).isDisplayed()) {
                foundStrings.add("First Row in Calendar Table");
                System.out.println("First Row in Calendar Table is displayed");
            }
         
        } catch (NoSuchElementException e) {
            e.printStackTrace();
        }

        List<String> expectedStrings = new ArrayList<>();
        List<List<String>> dtCells = dt.cells(); 

        for (List<String> cell : dtCells) {
            expectedStrings.addAll(cell);
        }

        for (int i = 0; i < expectedStrings.size(); i++) {
            if (i < foundStrings.size() && foundStrings.get(i).contains(expectedStrings.get(i))) {
            
            }
        }
        System.out.println("Expected fields in the Economic Calendar screen is : " + expectedStrings);
        System.out.println("Found fields in the Economic Calendar screen is : " + foundStrings);
        DriverFactory.DriverFactory.driver.switchTo().defaultContent();
    }
    
    
    public static void clickSliderButton(String date) {
    	DriverFactory.DriverFactory.driver.switchTo().frame("iFrameResizer0");
    	WebElement slider = DriverFactory.DriverFactory.driver.findElement(By.xpath("//mat-slider"));        
    	Actions action = new Actions(DriverFactory.DriverFactory.driver);
    	
    	if(date.equals("Today")) {
    		action.dragAndDropBy(slider, -100, 0).perform();
    	}
    	
    	if(date.equals("Tomorrow")) {
    		action.dragAndDropBy(slider, -50, 0).perform();
    	}
    	
    	if(date.equals("Next Week")) {
    		action.dragAndDropBy(slider, 50, 0).perform();
    	}
    	
    	if(date.equals("Next Month")) {
    		action.dragAndDropBy(slider, 150, 0).perform();    	
    	}
		System.out.println("Slider is clicked");
        DriverFactory.DriverFactory.driver.switchTo().defaultContent();
     	
    }
    
    
    public static void viewDateAsExpected(String date) {
    	DriverFactory.DriverFactory.driver.switchTo().frame("iFrameResizer0");
    	WebElement slider = DriverFactory.DriverFactory.driver.findElement(By.xpath("//mat-slider"));        

    	LocalDate today = LocalDate.now();
    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
    	String todayDate = today.format(formatter);
    	
    	LocalDate tomorrow = today.plusDays(1);
    	String tomorrowDate = tomorrow.format(formatter);
    	
    	LocalDate nextweek = today.plusWeeks(1);
    	String nextWeekDate = nextweek.format(formatter);
    	
    	LocalDate nextMonth = today.plusMonths(1);
    	String nextMonthDate = nextMonth.format(formatter);
    	
    	Actions action = new Actions(DriverFactory.DriverFactory.driver);
    	
    	if(date.equals("Today")) {
    		WebElement sliderLabel = DriverFactory.DriverFactory.driver.findElement(By.xpath("//tc-time-filter-container/div/div/span/span/div"));        
    		assert(sliderLabel.getText().equals("Today"));
    		System.out.println("Today's Date is displayed as expected " + todayDate);
    	}
    	
    	if(date.equals("Tomorrow")) {
    		WebElement sliderLabel = DriverFactory.DriverFactory.driver.findElement(By.xpath("//tc-time-filter-container/div/div/span/span/div"));        
    		assert(sliderLabel.getText().equals("Tomorrow"));
    		System.out.println("Tomorrow date is displayed as expected " + tomorrowDate);

    	}
    	
    	if(date.equals("Next Week")) {
    		WebElement sliderLabel = DriverFactory.DriverFactory.driver.findElement(By.xpath("//tc-time-filter-container/div/div/span/span/div"));        
    		assert(sliderLabel.getText().equals("Next Week"));
    		System.out.println("Next Week date is displayed as expected " + nextWeekDate);

    	}
    	
    	if(date.equals("Next Month")) {
    		WebElement sliderLabel = DriverFactory.DriverFactory.driver.findElement(By.xpath("//tc-time-filter-container/div/div/span/span/div"));        
    		assert(sliderLabel.getText().equals("Next Month"));
    		System.out.println("Next Month date is displayed as expected " + nextMonthDate);

    	}
    	
        DriverFactory.DriverFactory.driver.switchTo().defaultContent();     	
    }
    

    public void scrollToTheBottomOfScreen() {
   		WebElement disclaimerBlock = DriverFactory.DriverFactory.driver.findElement(By.xpath("//*[@id='research-app']/div[4]/div"));        
    	JavascriptExecutor js = (JavascriptExecutor) DriverFactory.DriverFactory.driver;
    	//js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
    	js.executeScript("arguments[0].scrollIntoView(true);", disclaimerBlock);
        System.out.println("The screen is scrolled to the Disclaimer Block");    
    } 
    
    public void verifyUserInNotificationScreen() {
   		WebElement notificationHeader = DriverFactory.DriverFactory.driver.findElement(By.xpath("//h2"));        
    	assert(notificationHeader.isDisplayed());
    	assert(notificationHeader.getText().equals("Notification on Non-Independent Investment Research and Risk Warning"));
        System.out.println("The User is in Notification Screen");    
    }
    
    public void clickLinkInRiskWarningBlock() {
   		WebElement riskClosureLink = DriverFactory.DriverFactory.driver.findElement(By.xpath("//*[@id=\"risk-block\"]/div/div/p/span[2]/a"));        
    	assert(riskClosureLink.isDisplayed());
    	assert(riskClosureLink.getText().equals("Risk Disclosure"));
        System.out.println("The User is in Risk Warning Block section");    
    } 
    	
    public void verifyDocumentOpensInNewTab() {
    	String currentTabTitle = DriverFactory.DriverFactory.driver.getTitle();
        System.out.println(currentTabTitle);        
   		WebElement riskClosureLink = DriverFactory.DriverFactory.driver.findElement(By.xpath("//*[@id=\"risk-block\"]/div/div/p/span[2]/a"));        
    	riskClosureLink.click();
        System.out.println("Risk Closure Link is clicked");        
        String originalTab = DriverFactory.DriverFactory.driver.getWindowHandle();
        String newTab = "";
        
        for (String handle : DriverFactory.DriverFactory.driver.getWindowHandles()) {
        	if(!handle.equals(originalTab)) {
        		DriverFactory.DriverFactory.driver.switchTo().window(handle);
        		handle = newTab;
        		break;
        	}
        }
        String newTabTitle = DriverFactory.DriverFactory.driver.getTitle();
        System.out.println(newTabTitle);        		
        if(!newTabTitle.equals(currentTabTitle)) {
        	System.out.println("The link opened the document in the new tab as expected");
        }
        else {
        	System.out.println("The link does not open the document in the new tab as expected");
      	
        }
    } 
    		  
		
}


