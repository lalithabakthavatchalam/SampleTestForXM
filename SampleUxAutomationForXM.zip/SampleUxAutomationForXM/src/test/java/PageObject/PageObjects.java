package PageObject;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObjects {
	
	@FindBy(xpath = "//*[@id='cookieModal']/div/div")
    public static WebElement preferenceModal;
	@FindBy(xpath = "//*[@id='cookieModal']/div/div/div[1]/div[3]/div[2]/div[3]/button")
    public static WebElement acceptAllButton;
	@FindBy(xpath = "//div[@id='main-nav")
    public static WebElement navigationBarForXM;
	@FindBy(xpath = "//*[@id=\\\"navigation-collapse\\\"]/div/div[1]/a")
    public static WebElement xmLogo;
	@FindBy(xpath = "//*[@id=\\\"hero-content\\\"]/div[4]/div[1]")
    public static WebElement contentBlock;	
	@FindBy(xpath = "//ul[@id='main-nav']/li")
    public static List<WebElement> navbarElements;
    @FindBy(xpath = "//div[@class='block']")
    public static List<WebElement> tabBlocksInResearchAndEducation;
    @FindBy(xpath = "//*[@id=\"main-nav\"]/li[4]/div/div/div[1]/span")
    public static WebElement researchAndEducationHeader;
    @FindBy(xpath = "//h2")
    public static WebElement economicCalendarHeader;
    @FindBy(xpath = "//div//tc-time-filter-container")
    public static WebElement calendarSection;
    @FindBy(xpath = "//tc-time-filter-container/div/div/span/mat-slider/div/div[3]/div[2]")
    public static WebElement calendarSlider;
    @FindBy(xpath = "//tc-economic-calendar-view-container/div/div/div[2]/div[1]/tc-time-filter-container/div/div/span/span/div")
    public static WebElement labelSectionInCalendar;
    @FindBy(xpath = "//*[@id=\"economic-calendar-list\"]/div[1]/div/span[1]")
    public static WebElement dateDisplayLabelSection;
    @FindBy(xpath = "//*[@id=\"risk-block\"]/div/div/p")
    public static WebElement riskBlock;
    @FindBy(xpath = "//*[@id=\"risk-block\"]/div/div/p/span[2]/a")
    public static WebElement riskClosureLink;


}
