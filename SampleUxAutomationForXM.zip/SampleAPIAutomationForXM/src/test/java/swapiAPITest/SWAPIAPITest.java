package swapiAPITest;

import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;


public class SWAPIAPITest extends BaseTest {
	
	@Test
	public void testFindFilmWithTitleANewHope() {
		SwapiAPI swapiAPI = new SwapiAPI();
		Response response = swapiAPI.findFilmWithTitle("A New Hope");
		
		Assert.assertEquals(response.getStatusCode(), 200);
		System.out.println("The status code is : " + response.getStatusCode());
		
		String filmTitle = response.path("results[0].title");
		Assert.assertEquals(filmTitle, "A New Hope");
		
		System.out.println("Film Title: " + filmTitle);
		System.out.println("Film Director: " + response.path("results[0].director"));
		System.out.println("Film URL: " + response.path("results[0].url"));
		System.out.println("Film Release Date: " + response.path("results[0].release_date"));
		System.out.println("Film Producer: " + response.path("results[0].producer"));

	}
	
	@Test(dependsOnMethods = "testFindFilmWithTitleANewHope")
	public void testFindCharacterByName() {
		Response response = given()
				.when()
					.get("people?search=Biggs Darklighter")
				.then()
					.statusCode(200)
					.extract()
					.response();
		
		String characterURL = response.jsonPath().getString("results[0].url");
		given()
			.when()
				.get(characterURL)
			.then()
				.statusCode(200)
				.body("name", equalTo("Biggs Darklighter"));
						
	}
	
	@Test(dependsOnMethods = "testFindCharacterByName")
	public void testFindStarshipByCharacters() {
		Response response = given()
				.when()
					.get("people?search=Biggs Darklighter")
				.then()
					.statusCode(200)
					.extract()
					.response();
		
		String starshipUrl = response.jsonPath().getString("results[0].starships[0]");
		given()
			.when()
				.get(starshipUrl)
			.then()
				.statusCode(200)
			.body("name", equalTo("X-wing"));
		
	}
	
	@Test(dependsOnMethods = "testFindStarshipByCharacters")
	public void testCheckStarshipDetails() {
		Response starshipResponse = given()
			.when()
				.get("starships?search=StarshipName")
			.then()
				.statusCode(200)
				.extract()
				.response();
		System.out.println("Starship Response body: " + starshipResponse.getBody().asString());
		
		String starshipClass = starshipResponse.jsonPath().getString("results[0].starship_class");
			
			Response pilotResponse = given()
				.when()
					.get("people?search=Luke Skywalker")
				.then()
					.statusCode(200)
					.extract()
					.response();
		
		System.out.println("Pilots Response body: " + pilotResponse.getBody().asString());
		
	
				given()
					.when()
						.get("starships?starship_class=Starfighter")
					.then()
						.statusCode(200)
						.body("results[0].starship.class", equalTo(starshipClass));
						//.body("results[0].pilots.name", hasItem("Luke Skywalker"));

	}

}
