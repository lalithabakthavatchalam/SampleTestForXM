package swapiAPITest;

public class APIEndPoints {
	
	public static final String Films = "/films/";
	public static final String People = "/people/";
	public static final String Starships = "/starships/";	

}
