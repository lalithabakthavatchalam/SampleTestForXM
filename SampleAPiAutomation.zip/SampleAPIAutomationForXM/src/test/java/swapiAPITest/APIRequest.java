package swapiAPITest;

import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

public class APIRequest {
	public Response sendGetRequest(String endpoint) {
		return given()
				.get(endpoint);
	}

}
