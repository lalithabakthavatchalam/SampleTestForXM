package swapiAPITest;

import io.restassured.response.Response;

public class SwapiAPI {
	
	private APIRequest apiRequest;
	
	public SwapiAPI() {
		apiRequest = new APIRequest();
	}
	
	public Response findFilmWithTitle(String title) {
		return apiRequest.sendGetRequest("/films/?search=" + title);
	}
	
	public Response findCharacterWithNameInFilm(String filmId, String characterName) {
		return apiRequest.sendGetRequest(characterName);
	}
	
	public Response findPersonWithNameInFilm(String filmURL, String personName) {
		String filmId = extractIdFromURL(filmURL);
		return apiRequest.sendGetRequest("/films/" + filmId + "/characters");
	}
	
	public Response findStarshipForPerson(String person) {
		return apiRequest.sendGetRequest(person);
	}
	
	public Response checkStarshipClassAndPilots(String starshipURL) {
		return apiRequest.sendGetRequest(starshipURL);
	}
	
	private String extractIdFromURL(String url) {
		String[] parts = url.split("/");
		return parts[parts.length -1];
	}

}
